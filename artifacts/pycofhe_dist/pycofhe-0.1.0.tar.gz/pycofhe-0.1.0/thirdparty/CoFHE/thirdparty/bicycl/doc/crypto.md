# Cryptographic primitives {#crypto}

## HSM

Reference: \cite{CTRSA15}

@see BICYCL::HSM
@see HSM.hpp
@see HSM_utils.hpp

