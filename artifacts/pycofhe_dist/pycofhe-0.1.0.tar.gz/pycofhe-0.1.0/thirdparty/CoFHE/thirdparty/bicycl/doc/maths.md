# Mathematical background {#maths}

## Imaginary quadratic fields
