#ifndef CUDA_CRYPTO_SYSTEM_HPP_INCLUDED
#define CUDA_CRYPTO_SYSTEM_HPP_INCLUDED
#error "Not implemented"
#endif